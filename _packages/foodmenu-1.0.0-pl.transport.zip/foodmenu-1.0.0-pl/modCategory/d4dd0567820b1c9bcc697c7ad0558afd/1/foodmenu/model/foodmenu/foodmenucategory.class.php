<?php
/**
 * @package foodmenu
 */
class FoodMenuCategory extends xPDOSimpleObject {}
?>