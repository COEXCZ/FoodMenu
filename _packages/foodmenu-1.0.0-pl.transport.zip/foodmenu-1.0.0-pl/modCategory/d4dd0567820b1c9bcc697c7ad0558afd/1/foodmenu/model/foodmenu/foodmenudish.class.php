<?php
/**
 * @package foodmenu
 */
class FoodMenuDish extends xPDOSimpleObject {}
?>